package 김나경_프로그래밍언어응용;

public interface AutomaticCarVehicle {
	public static final String accelerate = "자동 변속기 자동차가 가속합니다!";
	public static final String stop = "자동 변속기 자동차가 정차합니다!";
	public static final boolean setStart = false;

}
