package 김나경_프로그래밍언어응용;

public interface FreightTrainVehicle {
	public static final String accelerate = "화물 열차가 천천히 가속합니다!";
	public static final String stop = "화물 열차가 천천히 정차합니다!";
	public static final boolean setStart = true;

}
