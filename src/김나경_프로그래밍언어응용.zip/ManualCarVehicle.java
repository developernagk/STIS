package 김나경_프로그래밍언어응용;

public interface ManualCarVehicle {
	
	public static final String accelerate = "수동 변속기 자동차가 가속합니다!";
	public static final String stop = "수동 변속기 자동차가 정차합니다!";
	public static final boolean setStart = false;

}
