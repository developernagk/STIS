package 김나경_프로그래밍언어응용;

public interface PassengerTrainVehicle {
	public static final String accelerate = "여객 열차가 천천히 가속합니다!";
	public static final String stop = "여객 열차가 천천히 정차합니다!";
	public static final boolean setStart = false;

}
